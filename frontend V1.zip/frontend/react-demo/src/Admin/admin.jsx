import { Box } from '@mui/system';
import { useTheme } from '@mui/material/styles';
import { useMediaQuery, CssBaseline, Drawer, Toolbar, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import { Route, Routes } from "react-router-dom";
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import React from 'react';
import InventoryIcon from '@mui/icons-material/Inventory';
import DashboardIcon from '@mui/icons-material/Dashboard';
import GroupIcon from '@mui/icons-material/Group';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import CategoryIcon from '@mui/icons-material/Category';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import CreateProductForm from './components/CreateProductForm';
import OrdersTable from './components/OrdersTable';
import CustomersTable from './components/CustomersTable';
import ProductsTable from './components/ProductsTable';
import AdminDashboard from './components/Dashboard';// Assuming Dashboard is a component in './components/Dashboard'

const menu = [
    { name: "Dashboard", path: "/admin", icon: <DashboardIcon /> },
    { name: "Products", path: "/admin/products", icon: <CategoryIcon /> },
    { name: "Orders", path: "/admin/orders", icon: <InventoryIcon /> },
    { name: "AddProduct", path: "/admin/product/create", icon: <AddCircleIcon /> },
];

const Admin = () => {
    const theme = useTheme();
    const isLargeScreen = useMediaQuery(theme.breakpoints.up("lg"));
    const [sideBarVisible, setSidebarVisible] = useState(true);
    const navigate = useNavigate();

    const drawer = (
        <Box
            sx={{
                overflow: "auto",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                height: "100%",
            }}
        >
            <List>
                {menu.map((item) => (
                    <ListItem
                        key={item.name} disablePadding
                        onClick={() => navigate(item.path)}
                    >
                        <ListItemButton>
                            <ListItemIcon>
                                {item.icon}
                            </ListItemIcon>
                            <ListItemText primary={item.name} />
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>

            <List>
                <ListItem disablePadding>
                    <ListItemButton>
                        <ListItemIcon>
                            <AccountCircleIcon />
                        </ListItemIcon>
                        <ListItemText primary="Account" />
                    </ListItemButton>
                </ListItem>
            </List>
        </Box>
    );

    return (
        <div className='flex h-[100vh]'>
            <CssBaseline />
            <div className='w-[15%] border border-r-gray-300 h-full fixed top-0'>
                {drawer}
            </div>
            <div className=' w-[85%] ml-[15%]'>
                <Routes>
                    <Route path="/" element={<AdminDashboard />} />
                    <Route path="/product/create" element={<CreateProductForm />} />
                    <Route path="/orders" element={<OrdersTable />} />
                    <Route path="/products" element={<ProductsTable />} />
                </Routes>
            </div>
        </div>
    );
}

export default Admin;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, Box } from '@mui/material';
import CreateProductForm from './CreateProductForm';

const initialRows = [
  { name: 'Khaadi Kurta', price: 'PKR 2500', availability: 'In Stock', rating: 4.5 },
  { name: 'Gul Ahmed Lawn', price: 'PKR 3500', availability: 'In Stock', rating: 4.7 },
  { name: 'Sana Safinaz Pret', price: 'PKR 5500', availability: 'Out of Stock', rating: 4.9 },
  { name: 'Al Karam Collection', price: 'PKR 3200', availability: 'In Stock', rating: 4.6 },
  { name: 'Nishat Linen', price: 'PKR 4000', availability: 'In Stock', rating: 4.8 },
  { name: 'Junaid Jamshed Shalwar Kameez', price: 'PKR 4500', availability: 'In Stock', rating: 4.4 },
  { name: 'Bonanza Satrangi', price: 'PKR 2800', availability: 'Out of Stock', rating: 4.3 },
  { name: 'Bareeze Embroidered', price: 'PKR 6000', availability: 'In Stock', rating: 4.9 },
  { name: 'Ego Tunic', price: 'PKR 2000', availability: 'In Stock', rating: 4.2 },
  { name: 'Sapphire Unstitched', price: 'PKR 3700', availability: 'In Stock', rating: 4.6 },
  { name: 'Asim Jofa Luxury', price: 'PKR 7000', availability: 'Out of Stock', rating: 4.8 }
];

const ProductsTable = () => {
  const [rows, setRows] = useState(initialRows);
  const navigate = useNavigate();

  const handleDelete = (name) => {
    const updatedRows = rows.filter((row) => row.name !== name);
    setRows(updatedRows);
  };

  return (
    <TableContainer component={Paper}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', padding: 2 }}>
        <Button variant="contained" color="primary" onClick={() => navigate('/admin/product/create')}>
          Add Product
        </Button>
      </Box>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Product Name</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Price</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Availability</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Rating</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.name} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell align="right">{row.price}</TableCell>
              <TableCell align="right">{row.availability}</TableCell>
              <TableCell align="right">{row.rating}</TableCell>
              <TableCell align="right">
                <Button variant="contained" color="secondary" onClick={() => handleDelete(row.name)}>
                  Delete
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default ProductsTable;

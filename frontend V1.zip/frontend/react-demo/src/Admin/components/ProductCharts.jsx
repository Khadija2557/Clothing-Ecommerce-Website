import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const ProductsChart = ({ products }) => {
  const data = [
    { name: 'In Stock', value: products.filter(product => product.availability === 'In Stock').length },
    { name: 'Out of Stock', value: products.filter(product => product.availability === 'Out of Stock').length }
  ];

  return (
    <BarChart width={500} height={300} data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Bar dataKey="value" fill="#82ca9d" />
    </BarChart>
  );
};

export default ProductsChart;

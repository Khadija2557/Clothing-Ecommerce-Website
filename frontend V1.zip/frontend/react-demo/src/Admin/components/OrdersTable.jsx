import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button } from '@mui/material';

const initialOrders = [
  { id: 1, productName: 'Khaadi Kurta', price: 'PKR 2500', status: 'Pending', customerName: 'Ali' },
  { id: 2, productName: 'Gul Ahmed Lawn', price: 'PKR 3500', status: 'Pending', customerName: 'Ayesha' },
  { id: 3, productName: 'Sana Safinaz Pret', price: 'PKR 5500', status: 'Shipped', customerName: 'Sara' },
  { id: 4, productName: 'Al Karam Collection', price: 'PKR 3200', status: 'Pending', customerName: 'Hassan' },
  { id: 5, productName: 'Nishat Linen', price: 'PKR 4000', status: 'Shipped', customerName: 'Fatima' },
  { id: 6, productName: 'Junaid Jamshed Shalwar Kameez', price: 'PKR 4500', status: 'Pending', customerName: 'Ahmed' },
  { id: 7, productName: 'Bonanza Satrangi', price: 'PKR 2800', status: 'Pending', customerName: 'Zainab' },
  { id: 8, productName: 'Bareeze Embroidered', price: 'PKR 6000', status: 'Pending', customerName: 'Usman' },
  { id: 9, productName: 'Ego Tunic', price: 'PKR 2000', status: 'Shipped', customerName: 'Khadija' },
  { id: 10, productName: 'Sapphire Unstitched', price: 'PKR 3700', status: 'Pending', customerName: 'Bilal' },
  { id: 11, productName: 'Asim Jofa Luxury', price: 'PKR 7000', status: 'Pending', customerName: 'Maira' },
  { id: 12, productName: 'Maria B Lawn', price: 'PKR 5000', status: 'Shipped', customerName: 'Nida' },
  { id: 13, productName: 'Charcoal Suit', price: 'PKR 8000', status: 'Pending', customerName: 'Saad' },
  { id: 14, productName: 'Outfitters T-Shirt', price: 'PKR 1500', status: 'Pending', customerName: 'Zara' },
  { id: 15, productName: 'Levi\'s Jeans', price: 'PKR 6000', status: 'Shipped', customerName: 'Omar' }
];

const OrdersTable = () => {
  const [orders, setOrders] = useState(initialOrders);

  const handleDelete = (id) => {
    const updatedOrders = orders.filter((order) => order.id !== id);
    setOrders(updatedOrders);
  };

  const handleShip = (id) => {
    const updatedOrders = orders.map((order) =>
      order.id === id ? { ...order, status: 'Shipped' } : order
    );
    setOrders(updatedOrders);
  };

  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Order ID</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }}>Product Name</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Price</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Status</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Customer Name</TableCell>
            <TableCell sx={{ fontWeight: 'bold' }} align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
              <TableCell component="th" scope="row">
                {order.id}
              </TableCell>
              <TableCell>{order.productName}</TableCell>
              <TableCell align="right">{order.price}</TableCell>
              <TableCell align="right">{order.status}</TableCell>
              <TableCell align="right">{order.customerName}</TableCell>
              <TableCell align="right">
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleShip(order.id)}
                  disabled={order.status === 'Shipped'}
                  sx={{ mr: 1 }}
                >
                  Ship
                </Button>
                <Button variant="contained" color="secondary" onClick={() => handleDelete(order.id)}>
                  Delete
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default OrdersTable;

import React, {useState} from "react";

import { Grid, Paper } from "@mui/material";
import Achivement from "./Achivment";
import MonthlyOverview from "./MonthlyOverview";
import ProductsTable from "./ProductsTable";
import OrdersTable from "./OrdersTable";
import OrdersChart from "./OrderCharts";
import ProductsChart from "./ProductCharts";

const initialProducts = [
  {
    name: "Khaadi Kurta",
    price: "PKR 2500",
    availability: "In Stock",
    rating: 4.5,
  },
  {
    name: "Gul Ahmed Lawn",
    price: "PKR 3500",
    availability: "In Stock",
    rating: 4.7,
  },
  {
    name: "Sana Safinaz Pret",
    price: "PKR 5500",
    availability: "Out of Stock",
    rating: 4.9,
  },
  {
    name: "Al Karam Collection",
    price: "PKR 3200",
    availability: "In Stock",
    rating: 4.6,
  },
  {
    name: "Nishat Linen",
    price: "PKR 4000",
    availability: "In Stock",
    rating: 4.8,
  },
  {
    name: "Junaid Jamshed Shalwar Kameez",
    price: "PKR 4500",
    availability: "In Stock",
    rating: 4.4,
  },
  {
    name: "Bonanza Satrangi",
    price: "PKR 2800",
    availability: "Out of Stock",
    rating: 4.3,
  },
  {
    name: "Bareeze Embroidered",
    price: "PKR 6000",
    availability: "In Stock",
    rating: 4.9,
  },
  {
    name: "Ego Tunic",
    price: "PKR 2000",
    availability: "In Stock",
    rating: 4.2,
  },
  {
    name: "Sapphire Unstitched",
    price: "PKR 3700",
    availability: "In Stock",
    rating: 4.6,
  },
  {
    name: "Asim Jofa Luxury",
    price: "PKR 7000",
    availability: "Out of Stock",
    rating: 4.8,
  },
];

const initialOrders = [
  {
    id: 1,
    productName: "Khaadi Kurta",
    price: "PKR 2500",
    status: "Pending",
    customerName: "Ali",
  },
  {
    id: 2,
    productName: "Gul Ahmed Lawn",
    price: "PKR 3500",
    status: "Pending",
    customerName: "Ayesha",
  },
  {
    id: 3,
    productName: "Sana Safinaz Pret",
    price: "PKR 5500",
    status: "Shipped",
    customerName: "Sara",
  },
  {
    id: 4,
    productName: "Al Karam Collection",
    price: "PKR 3200",
    status: "Pending",
    customerName: "Hassan",
  },
  {
    id: 5,
    productName: "Nishat Linen",
    price: "PKR 4000",
    status: "Shipped",
    customerName: "Fatima",
  },
  {
    id: 6,
    productName: "Junaid Jamshed Shalwar Kameez",
    price: "PKR 4500",
    status: "Pending",
    customerName: "Ahmed",
  },
  {
    id: 7,
    productName: "Bonanza Satrangi",
    price: "PKR 2800",
    status: "Pending",
    customerName: "Zainab",
  },
  {
    id: 8,
    productName: "Bareeze Embroidered",
    price: "PKR 6000",
    status: "Pending",
    customerName: "Usman",
  },
  {
    id: 9,
    productName: "Ego Tunic",
    price: "PKR 2000",
    status: "Shipped",
    customerName: "Khadija",
  },
  {
    id: 10,
    productName: "Sapphire Unstitched",
    price: "PKR 3700",
    status: "Pending",
    customerName: "Bilal",
  },
  {
    id: 11,
    productName: "Asim Jofa Luxury",
    price: "PKR 7000",
    status: "Pending",
    customerName: "Maira",
  },
  {
    id: 12,
    productName: "Maria B Lawn",
    price: "PKR 5000",
    status: "Shipped",
    customerName: "Nida",
  },
  {
    id: 13,
    productName: "Charcoal Suit",
    price: "PKR 8000",
    status: "Pending",
    customerName: "Saad",
  },
  {
    id: 14,
    productName: "Outfitters T-Shirt",
    price: "PKR 1500",
    status: "Pending",
    customerName: "Zara",
  },
  {
    id: 15,
    productName: "Levi's Jeans",
    price: "PKR 6000",
    status: "Shipped",
    customerName: "Omar",
  },
];

const AdminDashboard = () => {
  const [products] = useState(initialProducts);
  const [orders] = useState(initialOrders);
  return (
    <div className="p-10">
      <Grid container spacing={2}>
        <Grid item x5={12} md={4}>
          <Achivement />
        </Grid>
        <Grid item x5={12} md={8}>
          <MonthlyOverview />
        </Grid>
        <Grid item xs={12} md={7}>
          <Paper elevation={3} sx={{ p: 2 }}>
            <ProductsChart products={products} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={5}>
          <Paper elevation={3} sx={{ p: 2 }}>
            <OrdersChart orders={orders} />
          </Paper>
        </Grid>
        <Grid item x5={12} md={12}>
          <ProductsTable />
        </Grid>
        <Grid item x5={12} md={12}>
          <OrdersTable />
        </Grid>
      </Grid>
    </div>
  );
};

export default AdminDashboard;
